// #name,parentName,isDirectory,content

var big =
[
    ["/", null, true, null],
    ["Notes", "/", true, null],
    ["Important", "/", true, null],
    [".Private", "/", true, null],
    ["readme.txt", "/", false, "BIG company server. Do NOT copy or export any files here."],
    ["schedule.txt", "Important", false, "From: boss@big.com<br/>From now on you are supposed to arrive one hour earlier and leave one hour later.<br/>"],
    ["announcement.txt", "Important",false, "From: boss@big.com<br/>From now on your mail passwords will have to be encrypted to ensure security in the company.<br/>Please make sure to change them soon.<br/>"],
    [".password.txt", ".Private",false, "butterfly"],
    ["roster.txt", "Notes", false, "ID :<br/>1	Denny Pittman<br/>2 Elly Donlin<br/>3 Jacquelyne Loop<br/>4 Lizabeth Samus<br/>5 Kyung Lucas<br/>6 Kelsi Schoenberger<br/>7 Big Boss<br/>8 Darin Yokota<br/>9 Kennith Finch <br/>"]
]
