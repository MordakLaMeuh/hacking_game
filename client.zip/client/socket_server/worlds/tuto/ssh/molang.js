// #name,parentName,isDirectory,content

var molang =
[
    ["/", null, true, null],
    ["Pictures", "/", true, null],
    [".Secret", "/", true, null],
    ["holidays.jpg", "Pictures", false, "You found a picture of Zero's holidays. Don't be so curious !"],
    [".hidden.txt", ".Secret", false, "Hey I couldn't talk to you about this on the phone... <br/>But I want info about a guy called Victor Young. It's important. He works for the BIG company. <br/> I got already got his e-mail : vyoung@big.com <br/> Check his social media profile as well (╭ರ_⊙)<br/> www.fakebook.com/vyoung"]
]
