//#name,parentName,isDirectory,content

var tutoVFS =
[
    ["/", null, true, null],
    ["readme.txt", "/", false, "Folders' names begin with an uppercase. Hidden files and folders' names begin with a dot."],
    ["Missions", "/", true, null],
    ["Programs", "/", true, null],
    ["mission.txt", "Missions", false, "Heyyyy ! Your mission is to connect to my computer via ssh - I left something for you there. My login is zero and my password... well I let you guess but I can tell you it's something meaningful to me"]
]
