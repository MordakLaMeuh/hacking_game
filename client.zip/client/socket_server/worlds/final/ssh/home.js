// #name,parentName,isDirectory,content

var home =
[
    ["/", null, true, null],
    ["readme.txt", "/", false, "Important : Folders' names begin with an uppercase. Hidden files and folders' names begin with a dot."],
    ["Missions", "/", true, null],
    ["Programs", "/", true, null],
    ["mission.txt", "Missions", false, "Hello. We have noticed a suspicious application to our school. We would like you to help us to gather information about this student as they show wonderful potential.<br/>You can access the data we have by connection through 'ssh'.<br/>The login is 42 and the password is the name of the school cat."]
]
